const prisma = require('../config/prisma');
const AppError = require('../utils/AppError');

const DEFAULT_DELIVERY_FEE = Number(process.env.DEFAULT_DELIVERY_FEE) || 0;

/**
 * Builds the order items and totals from scratch using ONLY data from the
 * database. The frontend cart is only used to know WHICH products and
 * quantities were selected — never trusted for prices or names.
 */
async function buildOrderItems(requestedItems) {
  const productIds = [...new Set(requestedItems.map((item) => Number(item.produtoId)))];

  const products = await prisma.product.findMany({
    where: { id: { in: productIds } },
  });

  const productsById = new Map(products.map((p) => [p.id, p]));

  const orderItemsData = [];
  let valorProdutos = 0;

  for (const requested of requestedItems) {
    const produtoId = Number(requested.produtoId);
    const quantidade = Number(requested.quantidade);

    if (!Number.isInteger(quantidade) || quantidade <= 0) {
      throw new AppError(`Invalid quantity for product ${produtoId}`, 422);
    }

    const product = productsById.get(produtoId);

    if (!product) {
      throw new AppError(`Product ${produtoId} does not exist`, 404);
    }

    if (!product.disponivel) {
      throw new AppError(`Product "${product.nome}" is not available`, 409);
    }

    const precoUnitario = Number(product.preco);
    const subtotal = Number((precoUnitario * quantidade).toFixed(2));

    valorProdutos += subtotal;

    orderItemsData.push({
      produtoId: product.id,
      nomeProduto: product.nome,
      quantidade,
      precoUnitario,
      subtotal,
    });
  }

  valorProdutos = Number(valorProdutos.toFixed(2));

  return { orderItemsData, valorProdutos };
}

async function createOrder(payload) {
  const { itens, taxaEntrega } = payload;

  if (!Array.isArray(itens) || itens.length === 0) {
    throw new AppError('itens must be a non-empty array', 422);
  }

  const { orderItemsData, valorProdutos } = await buildOrderItems(itens);

  const fee = taxaEntrega !== undefined && taxaEntrega !== null
    ? Number(taxaEntrega)
    : DEFAULT_DELIVERY_FEE;

  const valorTotal = Number((valorProdutos + fee).toFixed(2));

  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        nomeCliente: payload.nomeCliente,
        telefone: payload.telefone,
        endereco: payload.endereco,
        numero: payload.numero,
        complemento: payload.complemento ?? null,
        bairro: payload.bairro,
        cidade: payload.cidade,
        observacao: payload.observacao ?? null,
        formaPagamento: payload.formaPagamento,
        valorProdutos,
        taxaEntrega: fee,
        valorTotal,
        status: 'pending',
        itens: {
          create: orderItemsData,
        },
      },
      include: { itens: true },
    });

    return created;
  });

  return order;
}

async function listOrders(filters = {}) {
  const { status, page = 1, limit = 20 } = filters;

  const where = {};
  if (status) where.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const take = Number(limit);

  const [items, total] = await Promise.all([
    prisma.order.findMany({
      where,
      include: { itens: true },
      orderBy: { criadoEm: 'desc' },
      skip,
      take,
    }),
    prisma.order.count({ where }),
  ]);

  return {
    items,
    meta: {
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / Number(limit)) || 1,
    },
  };
}

async function getOrderById(id) {
  const order = await prisma.order.findUnique({
    where: { id: Number(id) },
    include: { itens: true },
  });
  if (!order) throw new AppError('Order not found', 404);
  return order;
}

async function updateOrderStatus(id, status) {
  await getOrderById(id); // ensures 404 if missing

  return prisma.order.update({
    where: { id: Number(id) },
    data: { status },
    include: { itens: true },
  });
}

async function deleteOrder(id) {
  await getOrderById(id); // ensures 404 if missing
  // OrderItem rows cascade-delete automatically (see prisma schema onDelete: Cascade)
  await prisma.order.delete({ where: { id: Number(id) } });
}

module.exports = {
  createOrder,
  listOrders,
  getOrderById,
  updateOrderStatus,
  deleteOrder,
};
