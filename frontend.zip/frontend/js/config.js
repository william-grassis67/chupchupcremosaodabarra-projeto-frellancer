/* =========================================================
   CONFIG — configurações globais da aplicação
   ========================================================= */

// Altere aqui caso o backend esteja em outro host/porta.
const API_URL = "http://localhost:3000/api";

// Chave usada para persistir o carrinho no localStorage.
const CART_STORAGE_KEY = "chupchup:cart";

// Quantidade de produtos por página no cardápio.
const PRODUCTS_PAGE_SIZE = 12;

// Tempo (ms) de debounce da busca de produtos.
const SEARCH_DEBOUNCE_MS = 400;

// Valor de entrega exibido no resumo do carrinho.
// O backend é responsável pelo cálculo final do pedido;
// este valor é apenas informativo na tela do cliente.
const DELIVERY_FEE = 5;

// Opções de forma de pagamento aceitas.
// Ajuste os "value" para bater exatamente com o que o backend espera.
const PAYMENT_METHODS = [
  {
    value: "pix",
    label: "Pix",
    desc: "Pagamento instantâneo, confirmação na hora",
  },
  {
    value: "credit_card",
    label: "Cartão de crédito",
    desc: "Pagamento na entrega, maquininha do entregador",
  },
  {
    value: "debit_card",
    label: "Cartão de débito",
    desc: "Pagamento na entrega, maquininha do entregador",
  },
  {
    value: "cash",
    label: "Dinheiro",
    desc: "Pagamento na entrega",
  },
];
