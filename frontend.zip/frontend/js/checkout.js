/* =========================================================
   CHECKOUT — formulário de entrega/pagamento e criação do
   pedido via POST /api/orders.
   ========================================================= */

const Checkout = (function () {
  const form = document.getElementById("checkoutForm");
  const summaryItemsEl = document.getElementById("summaryItems");
  const summarySubtotalEl = document.getElementById("summarySubtotal");
  const summaryDeliveryEl = document.getElementById("summaryDelivery");
  const summaryTotalEl = document.getElementById("summaryTotal");
  const paymentOptionsEl = document.getElementById("paymentOptions");
  const submitBtn = document.getElementById("submitOrderBtn");
  const submitErrorEl = document.getElementById("submitError");
  const emptyNoticeEl = document.getElementById("checkoutEmptyNotice");
  const checkoutContentEl = document.getElementById("checkoutContent");

  function formatPrice(value) {
    return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function renderSummary() {
    const state = Cart.getState();

    summaryItemsEl.innerHTML = state.items
      .map(
        (item) => `
        <div class="summary-item">
          <span class="summary-item-name">${item.quantity}x ${escapeHtml(item.name)}</span>
          <span class="summary-item-qty">${formatPrice(item.price * item.quantity)}</span>
        </div>`
      )
      .join("");

    summarySubtotalEl.textContent = formatPrice(state.subtotal);
    summaryDeliveryEl.textContent = formatPrice(state.deliveryFee);
    summaryTotalEl.textContent = formatPrice(state.total);
  }

  function renderPaymentOptions() {
    paymentOptionsEl.innerHTML = PAYMENT_METHODS.map(
      (method, index) => `
      <label class="radio-card">
        <input type="radio" name="paymentMethod" value="${method.value}" ${index === 0 ? "checked" : ""} required />
        <span>
          <span class="radio-label">${escapeHtml(method.label)}</span><br />
          <span class="radio-desc">${escapeHtml(method.desc)}</span>
        </span>
      </label>`
    ).join("");
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function clearFieldErrors() {
    form.querySelectorAll(".field.has-error").forEach((field) => {
      field.classList.remove("has-error");
    });
    submitErrorEl.classList.remove("is-visible");
    submitErrorEl.textContent = "";
  }

  function setFieldError(name, message) {
    const field = form.querySelector(`[data-field="${name}"]`);
    if (!field) return;
    field.classList.add("has-error");
    const errorEl = field.querySelector(".error-msg");
    if (errorEl) errorEl.textContent = message;
  }

  function validate(formData) {
    let valid = true;
    const required = {
      customerName: "Informe o nome completo.",
      customerPhone: "Informe um telefone para contato.",
      street: "Informe o endereço.",
      number: "Informe o número.",
      neighborhood: "Informe o bairro.",
      city: "Informe a cidade.",
    };

    Object.entries(required).forEach(([name, message]) => {
      if (!formData.get(name) || !formData.get(name).toString().trim()) {
        setFieldError(name, message);
        valid = false;
      }
    });

    if (Cart.isEmpty()) {
      valid = false;
    }

    return valid;
  }

  function buildOrderPayload(formData) {
    return {
      customer: {
        name: formData.get("customerName").trim(),
        phone: formData.get("customerPhone").trim(),
      },
      address: {
        street: formData.get("street").trim(),
        number: formData.get("number").trim(),
        complement: (formData.get("complement") || "").trim(),
        neighborhood: formData.get("neighborhood").trim(),
        city: formData.get("city").trim(),
      },
      paymentMethod: formData.get("paymentMethod"),
      notes: (formData.get("notes") || "").trim(),
      items: Cart.getItems().map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
      })),
    };
  }

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.textContent = isLoading
      ? "Enviando pedido..."
      : "Finalizar pedido";
  }

  async function handleSubmit(event) {
    event.preventDefault();
    clearFieldErrors();

    if (submitBtn.disabled) return; // evita envios duplicados

    const formData = new FormData(form);

    if (Cart.isEmpty()) {
      submitErrorEl.textContent = "Seu carrinho está vazio.";
      submitErrorEl.classList.add("is-visible");
      return;
    }

    if (!validate(formData)) {
      submitErrorEl.textContent = "Verifique os campos destacados.";
      submitErrorEl.classList.add("is-visible");
      return;
    }

    const payload = buildOrderPayload(formData);
    setLoading(true);

    try {
      const order = await api.createOrder(payload);
      Cart.clear();
      const orderId = order && (order.id ?? order._id ?? order.orderId);
      sessionStorage.setItem(
        "chupchup:lastOrder",
        JSON.stringify({ id: orderId })
      );
      window.location.href = "success.html";
    } catch (err) {
      setLoading(false);
      submitErrorEl.textContent =
        err.message || "Não foi possível finalizar o pedido. Tente novamente.";
      submitErrorEl.classList.add("is-visible");

      if (err.errors) {
        Object.entries(err.errors).forEach(([field, message]) => {
          setFieldError(field, Array.isArray(message) ? message[0] : message);
        });
      }
    }
  }

  function renderEmptyState() {
    const isEmpty = Cart.isEmpty();
    emptyNoticeEl.hidden = !isEmpty;
    checkoutContentEl.hidden = isEmpty;
  }

  function init() {
    if (!form) return; // não estamos na página de checkout

    renderEmptyState();
    if (Cart.isEmpty()) return;

    renderSummary();
    renderPaymentOptions();
    Cart.onChange(() => {
      renderEmptyState();
      if (!Cart.isEmpty()) renderSummary();
    });
    form.addEventListener("submit", handleSubmit);
  }

  return { init };
})();
