# Chup Chup Gourmet — Frontend de Delivery

Frontend completo de um site de delivery, construído em **HTML5, CSS3 e JavaScript Vanilla** (sem frameworks, sem bibliotecas), integrado a uma API REST própria.

## 🍧 Sobre o projeto

Site institucional/cardápio para a marca **Chup Chup Gourmet**, onde o cliente:

1. Navega pelo cardápio (com filtro por categoria e busca textual);
2. Monta o carrinho (persistido em `localStorage`);
3. Preenche os dados de entrega e pagamento no checkout;
4. Finaliza o pedido, que é enviado ao backend via `POST /api/orders`;
5. Recebe a confirmação com o número real do pedido.

Não há login, cadastro ou qualquer autenticação — é um fluxo 100% público, como um cardápio digital.

## 🛠️ Tecnologias

- HTML5 semântico
- CSS3 puro (custom properties, grid, flexbox) — zero frameworks (sem Bootstrap/Tailwind)
- JavaScript Vanilla (ES6+, módulos via IIFE) — sem React/Vue/Angular/jQuery
- `fetch` nativo para consumo da API
- `localStorage` para persistência do carrinho

## 📁 Estrutura

```
frontend/
├── index.html              # Página inicial (hero, categorias, cardápio)
├── pages/
│   ├── checkout.html       # Formulário de entrega e pagamento
│   └── success.html        # Confirmação do pedido
├── css/
│   ├── variables.css       # Todos os tokens de design (cor, tipo, espaçamento)
│   ├── reset.css
│   ├── global.css          # Tipografia, botões, badges, estados, formulários
│   ├── header.css
│   ├── hero.css
│   ├── categories.css
│   ├── products.css
│   ├── cart.css            # Drawer do carrinho + barra fixa mobile
│   ├── checkout.css
│   ├── success.css
│   └── responsive.css
├── js/
│   ├── config.js           # URL da API e constantes globais
│   ├── api.js              # Única camada de comunicação com o backend
│   ├── cart.js             # Estado e persistência do carrinho
│   ├── categories.js       # Busca e filtro de categorias
│   ├── products.js         # Renderização, busca (debounce) e paginação
│   ├── checkout.js         # Validação do formulário e criação do pedido
│   └── main.js             # Inicialização, UI do carrinho e toast
└── assets/
    └── images/
        └── logo.jpg         # Selo da marca
```

## ▶️ Como executar

Este é um frontend estático — não precisa de build nem de `npm install`.

1. Suba o backend em `http://localhost:3000` (endpoints em `/api/*`).
2. Sirva a pasta `frontend/` com qualquer servidor estático, por exemplo:

   ```bash
   npx serve frontend
   # ou
   python3 -m http.server 5500 --directory frontend
   ```

3. Abra `http://localhost:5500` (ou a porta usada) no navegador.

> Abrir o `index.html` diretamente com duplo clique (`file://`) também funciona na maioria dos navegadores, mas um servidor estático é recomendado para evitar bloqueios de CORS/módulos.

## ⚙️ Configuração da API

A URL base da API fica centralizada em `js/config.js`:

```javascript
const API_URL = "http://localhost:3000/api";
```

Altere esse valor caso o backend esteja rodando em outro host, porta ou domínio (ex.: ambiente de homologação/produção).

## 🔌 Endpoints utilizadas pelo frontend

| Ação no site | Endpoint |
|---|---|
| Listar cardápio / filtrar por categoria / buscar / paginar | `GET /api/products?available=true&category=&search=&page=&limit=` |
| Buscar categorias para os filtros | `GET /api/categories` |
| Criar pedido no checkout | `POST /api/orders` |

Todas as chamadas passam exclusivamente por `js/api.js` — nenhum outro arquivo faz `fetch()` diretamente. As respostas são tratadas no padrão do backend:

```json
{ "success": true, "data": {} }
{ "success": false, "message": "...", "errors": {} }
```

## ⚠️ Sobre o formato dos dados (importante)

O backend real não estava disponível no mesmo workspace para leitura de controllers/DTOs no momento da construção deste frontend. Por isso:

- `js/products.js` e `js/categories.js` possuem uma função `normalize()` que aceita as variações mais comuns de nomes de campo (ex.: `image` / `imageUrl` / `image_url`, `available` / `isAvailable`, `category` / `categoryName`).
- `js/checkout.js` monta o payload do pedido em `buildOrderPayload()` com uma estrutura razoável (`customer`, `address`, `paymentMethod`, `notes`, `items: [{ productId, quantity }]`).

**Antes de apresentar ao cliente**, confira os nomes reais de propriedades no backend (controllers/validators/DTOs) e ajuste:
- as funções `normalize()` em `js/products.js` e `js/categories.js`;
- a função `buildOrderPayload()` em `js/checkout.js`;
- a lista `PAYMENT_METHODS` em `js/config.js` (os `value` devem bater com o que o backend espera).

O frontend **nunca** confia no preço vindo do próprio carrinho para o pedido final — apenas envia produto e quantidade; quem calcula o total é o backend.

## ✅ Funcionalidades

- Header com logo, navegação e contador de itens no carrinho
- Hero de apresentação da marca
- Filtro de categorias (via API, não apenas visual) + opção "Todos"
- Busca de produtos com debounce (400ms)
- Paginação real (via `page`/`limit` da API)
- Cards de produto com imagem, descrição, preço, categoria, selo de destaque e disponibilidade
- Produtos indisponíveis não podem ser adicionados ao carrinho
- Carrinho persistido em `localStorage`: adicionar, incrementar, decrementar, remover, limpar, subtotal e total
- Barra fixa de carrinho no mobile
- Checkout com validação de campos obrigatórios, seleção de pagamento, observações, estado de carregamento no botão e bloqueio de envios duplicados
- Tratamento de erros da API (mensagem geral + erros por campo, quando enviados)
- Página de sucesso com o número real do pedido retornado pela API
- Estados visuais de carregando, API indisponível, nenhum produto encontrado e carrinho vazio
- HTML semântico, labels, `alt` em imagens, foco visível e navegação por teclado

## 🧪 Como testar

1. Com o backend rodando, acesse a página inicial e confira se as categorias e produtos carregam.
2. Teste a busca digitando um termo existente e um inexistente (estado "nenhum produto encontrado").
3. Desligue o backend momentaneamente e recarregue a página para ver o estado de "API indisponível".
4. Adicione produtos ao carrinho, altere quantidades, remova um item e esvazie o carrinho.
5. Vá para o checkout com o carrinho vazio (deve mostrar o aviso de carrinho vazio).
6. Preencha o checkout com o carrinho cheio e finalize o pedido — confira o redirecionamento para a página de sucesso com o número do pedido.
7. Redimensione a janela para simular mobile e confira a barra fixa do carrinho.
